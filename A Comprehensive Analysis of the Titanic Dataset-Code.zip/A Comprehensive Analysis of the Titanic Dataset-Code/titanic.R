# handling missing data
# handling realistic data
#1. What was the survival rate?
#2. what was the distribution of Passenger Ages in Titanic?
#3. What was the survival rates by age?
#4. What was the gender Proportions in Titanic?
#5. What was the survival rate by gender?
#6. What was the ticket Class Proportions?
#7. What was the Passenger Distribution by Ticket Class and Gender?
#8. what was the passenger Count and Percentage by Embarkation Point?
#9. What was the survival rate by class of ticket?
#10. What was the survival rates by fare and age?
#11. what was theMulti-variate analysis pclass – sex – survived?


# Libraries
library(tidyverse)
library(dslabs)
library(ggplot2)
library(dplyr)

# Load an external CSV file
TitanicData <- read.csv("../titanic.csv")

#Sorting data
sort(TitanicData$total)
str(TitanicData)

#--------------------Missing values on ‘embarked’ column------------------------

# Check missing embarked data
table(is.na(TitanicData$embarked))

# Filter rows in the Titanic data set where "Embarked" is empty (contains NA values)
TitanicFiltered <- TitanicData %>%
  filter(is.na(embarked))

# Replace empty values with NA in the entire dataset
TitanicData <- TitanicData %>% 
  mutate_all(~ifelse(. == "", NA, .))

# Create a subset without missing values in the "Embarked" column
TrainTitanic <- TitanicData[!is.na(TitanicData$embarked), ]

# Find missing values in the "Embarked" column
MissingEmbarked <- TitanicData[is.na(TitanicData$embarked), ]

# Print the missing values
print(MissingEmbarked)

# Explore the data to see the most common value in the "embarked" column
table(TitanicData$embarked)

# Impute missing values in the "Embarked" column with "S"
TitanicData$embarked <- ifelse(
  is.na(TitanicData$embarked),
  "S",
  TitanicData$embarked
)

#------------------End Missing values on ‘embarked’ column----------------------

#----------------Missing and negative values on ‘age’ column--------------------

# Print negative age values
NegativeAgeValues <- TitanicData$age[TitanicData$age < 0]
print("Negative Age Values:")
print(NegativeAgeValues)

# Check missing age data
table(is.na(TitanicData$age))

# Check which rows in the "Age" column have missing values
MissingAge <- is.na(TitanicData$age)

# Create a linear regression model for age imputation
LmModel <- lm(
  age ~ pclass + sibsp + parch + fare + embarked,
  data = TitanicData
)

# Impute Missing Ages Using the Regression Model
# Create a subset of the data with missing ages
MissingAgeData <- TitanicData[MissingAge,]

# Predict missing ages
PredictedAges <- predict(LmModel, newdata = MissingAgeData)

# Replace missing values with predicted ages
TitanicData$age[MissingAge] <- PredictedAges

# To correct negative age values in the Titanic dataset
# Convert 'age' to numeric (if it's not already)
TitanicData$age <- as.numeric(as.character(TitanicData$age))

# Identify and replace negative ages with the mean age
MeanAge <- mean(TitanicData$age[TitanicData$age >= 0], na.rm = TRUE)
TitanicData$age[TitanicData$age < 0] <- MeanAge


#--------------End Missing and negative values on ‘fare’ column-----------------

#----------------Missing and negative values on ‘fare’ column-------------------
# Check which rows in the "Fare" column have missing values
# Check for missing fare values
MissingFare <- is.na(TitanicData$fare)
print("Missing Fare Values:")
print(sum(MissingFare))

# Filter out rows with negative fare values
NegativeFareValues <- TitanicData$fare[TitanicData$fare < 0]
print("Negative Fare Values:")
print(NegativeFareValues)

# Remove rows with negative fare values
TitanicData <- TitanicData %>%
  filter(fare >= 0)

# Check which rows in the "Fare" column have missing values
MissingFare <- is.na(TitanicData$fare)

# Create a linear regression model for fare imputation
LmModelFare <- lm(
  fare ~ pclass + age + sibsp + parch + embarked,
  data = TitanicData
)

# Impute Missing Fares Using the Regression Model
# Create a subset of the data with missing fares
MissingFareData <- TitanicData[MissingFare,]

# Predict missing fares
PredictedFares <- predict(LmModelFare, newdata = MissingFareData)

# Replace missing values with predicted fares
TitanicData$fare[MissingFare] <- PredictedFares

#--------------End Missing and negative values on ‘fare’ column-----------------

# Check for Missing Data
any(is.na(TitanicData$embarked))
any(is.na(TitanicData$age))
any(is.na(TitanicData$fare))
#-------------------------------------------------------------------------

#----------------------------The survival rate?---------------------------------
#1. What was the survival rate?
# Calculate percentages
PercentageData <- TitanicData %>%
  group_by(survived) %>%
  summarise(Count = n()) %>%
  mutate(Percentage = Count / sum(Count) * 100)

# Custom colors
PerishedColour <- "#D62828"
SurvivalColour <- "#F77F00"

# Convert 'survived' to a factor
PercentageData$survived <- factor(
  PercentageData$survived,
  labels = c("Perished", "Survival")
)

# Create a bar plot for survival rates with custom colors
ggplot(PercentageData, aes(x = survived, y = Count, fill = survived)) +
  geom_bar(stat = "identity", color = "black") +
  geom_text(aes(label = paste0(round(Percentage, 2), "%")), vjust = -0.5, size = 3) +
  scale_fill_manual(values = c(Perished = PerishedColour, Survival = SurvivalColour)) +
  labs(x = "Titanic Survival Rate"
       , y = "Passenger Count"
       , title = "Titanic Survival Rates") +
  theme_minimal()

#----------------------------End survival rate----------------------------------

#--------------------------distribution of Passenger Ages-----------------------
#2. what was the distribution of Passenger Ages in Titanic?
# Create age categories
# Defines the age intervals for categorization (0-12, 13-18, 19-35, 36-60, 61-100)
AgeBins <- c(0, 12, 18, 35, 60, 100)
AgeLabels <- c("Child <0-12>", "Teenager <13-18>", "Young Adult <19-35>", "Middle Age <36-60>", "Old <61-100>")
TitanicData$AgeCategory <- cut(
  TitanicData$age,
  breaks = AgeBins,
  labels = AgeLabels,
  include.lowest = TRUE
)

# Create a bar plot for age categories with custom colors
ggplot(TitanicData, aes(x = AgeCategory, fill = sex)) +
  geom_bar(position = "dodge", color = "black", show.legend = TRUE) +
  labs(
    title = "Age Categories of Titanic Passengers",
    x = "Age Category",
    y = "Count",
    fill = "sex"
  ) +
  scale_fill_manual(values = c("#F77F00", "#D62828")) +
  theme_minimal()

#---------------------End distribution of Passenger Ages------------------------

# ---------------------------Survival rates by age?-----------------------------

#3. What was the survival rates by age?
# Custom colors
FemaleColour <- "#F77F00"
MaleColour <- "#D62828"

# Create a boxplot for age distribution by gender with custom colors
ggplot(TitanicData, aes(x = sex, y = age, fill = sex)) +
  geom_boxplot(color = "black") +
  scale_fill_manual(values = c(female = FemaleColour, male = MaleColour)) +  # Set custom fill colors
  labs(
    title = "Age Distribution by Gender in Titanic Dataset",
    y = "Age Of Passenger",
    x = "Passenger Gender"
  ) +
  theme_minimal()

#--------------------------End survival rate by age-----------------------------


# -----------------------Gender Proportions in Titanic--------------------------

#4. What was the gender Counts in Titanic?
# Filter the dataset to only include passengers with known genders
TitanicFiltered <- TitanicData[!is.na(TitanicData$sex), ]

# Calculate gender counts
GenderCounts <- TitanicFiltered %>%
  group_by(sex) %>%
  summarise(GenderCount = n())

# Create a bar plot with count labels
ggplot(GenderCounts, aes(
  x = factor(sex, labels = c("Female", "Male")),
  y = GenderCount
)) +
  geom_bar(
    stat = "identity",
    aes(fill = sex),
    alpha = 0.8,
    color = "black"
  ) +
  geom_text(
    aes(label = GenderCount),
    vjust = -0.5,
    size = 3
  ) +  # Add count labels
  labs(
    x = "Gender",
    y = "Gender Count",
    title = "Gender Counts in Titanic"
  ) +
  scale_fill_manual(
    values = c( "#F77F00" , "#D62828" ),
    name = "Gender",
    labels = c("Female", "Male")
  ) +  # Specify colors for male and female
  theme_bw()


#----------------------End gender Proportions in Titanic------------------------

#-------------------------survival rate by gender?------------------------------
#5. What was the survival rate by gender?
# Filter the dataset to only include passengers with known genders
TitanicData <- TitanicData %>%
  filter(!is.na(sex))  # 'Sex' is used instead of 'sex'

# Calculate the number of passengers and survival percentage for each gender
GenderData <- TitanicData %>%
  group_by(sex, survived) %>%
  summarise(
    PassengerCount = n()
  ) %>%
  group_by(sex) %>%
  mutate(SurvivalPercentage = (PassengerCount / sum(PassengerCount)) * 100)

# Create a bar scatter plot with passenger count and survival percentage
ggplot(GenderData, aes(
  x = sex,
  y = PassengerCount,
  fill = factor(survived)
)) +
  geom_col(
    position = "dodge",
    color = "black",
    alpha = 0.8
  ) +
  geom_text(
    aes(label = paste0(round(SurvivalPercentage, 1), "%")),
    position = position_dodge(width = 0.8),
    vjust = -0.5
  ) +
  labs(
    x = "Gender",
    y = "Passenger Count",
    title = "Titanic Passenger Distribution and Survival Percentage by Gender"
  ) +
  scale_fill_manual(
    values = c("#D62828", "#F77F00"),
    name = "Survived",
    labels = c("Perished", "Survived")
  ) +
  theme_bw()


#--------------------------End survival rate by gender--------------------------

#--------------------------- ticket Class Proportions---------------------------

#6. What was the ticket Class Proportions?
# Filter the dataset to only include passengers with known classes
# Calculate passenger counts
PassengerCounts <- table(TitanicData$pclass)

# Convert counts to a data frame
PassengerCountsDf <- as.data.frame(PassengerCounts)
names(PassengerCountsDf) <- c("Passenger_Class", "Count")

# Create a bar plot
ggplot(PassengerCountsDf, aes(
  x = factor(Passenger_Class, labels = c("1st Class", "2nd Class", "3rd Class")),
  y = Count
)) +
  geom_bar(
    stat = "identity",
    fill = c("#D62828", "#F77F00", "#EAE2B7"),
    color = "black",
    alpha = 0.8
  ) +
  geom_text(
    aes(label = Count),
    vjust = -0.5,
    size = 3
  ) +  # Add count labels
  labs(
    x = "Passenger Class",
    y = "Passenger Count",
    title = "Number of Passengers in Each Class"
  ) +
  theme_bw()

#-----------------------End ticket Class Proportions----------------------------

#---------------Passenger Distribution by Ticket Class and Gender---------------

#7. what was the Passenger Distribution by Ticket Class and Gender
ggplot(TitanicData, aes(
  x = factor(pclass, labels = c("1st Class", "2nd Class", "3rd Class")),
  fill = sex
)) +
  geom_bar(
    position = position_dodge(0.8),
    stat = "count",
    width = 0.7,
    color = "black",
    alpha = 0.8
  ) +
  labs(
    x = "Passenger Ticket Class",
    y = "Passenger Count",
    title = "Passenger Distribution by Ticket Class and Gender"
  ) +
  scale_fill_manual(
    values = c("#F77F00", "#D62828"),
    name = "Gender",
    labels = c("Female", "Male")
  ) +
  theme_bw()

# Create a contingency table for pclass, sex, and survived
ContingencyTable <- table(
  TitanicData$pclass,
  TitanicData$sex,
  TitanicData$survived
)

# Display the contingency table
print(ContingencyTable)


#--------------End Passenger Distribution by Ticket Class and Gender------------

# Check missing fare data
table(is.na(TitanicData$fare))

# Bar plot of 'Fare' by 'Embarked'

# Passenger Count and Percentage by Embarkation Point
# Calculate percentages by embarkation point
EmbarkedPercentages <- TitanicData %>%
  filter(!is.na(embarked)) %>%
  group_by(embarked) %>%
  summarise(count = n()) %>%
  mutate(percentage = count / sum(count) * 100)

# Custom colors
CherbourgColour <- "#D62828"
QueenstownColour <- "#F77F00"
SouthamptonColour <- "#EAE2B7"

# Create a bar plot with percentages and counts, and black border around bars
ggplot(EmbarkedPercentages, aes(
  x = embarked,
  y = count,
  fill = embarked
)) +
  geom_bar(
    position = "dodge",
    stat = "identity",
    color = "black",  # Add a black border around the bars
    fill = c(CherbourgColour, QueenstownColour, SouthamptonColour)
  ) +
  geom_text(
    aes(
      label = paste0(count, " (", round(percentage, 1), "%)")
    ),
    position = position_dodge(width = 0.8),
    vjust = -0.5,
    size = 3
  ) +
  labs(
    title = "Passenger Distribution by Embarkation Point"
  ) +
  scale_x_discrete(labels = c("Cherbourg"
                            , "Queenstown"
                            , "Southampton"))+
  theme_minimal() + theme(panel.background = element_rect(fill = "white"))


#------------End passenger Count,Percentage by Embarkation Point----------------

#------------------------The survival rate by class of ticket-------------------
#9. What was the survival rate by class of ticket?
# Calculate survival percentages by ticket class
SurvivalByClass <- TitanicData %>%
  group_by(pclass, survived) %>%
  summarise(count = n()) %>%
  group_by(pclass) %>%
  mutate(percentage = count / sum(count) * 100)

# Custom colors
SurvivedColors <- c("#D62828", "#F77F00")

# Create a bar chart with percentages and black border around bars
ggplot(SurvivalByClass, aes(
  x = factor(pclass, labels = c("1st Class", "2nd Class", "3rd Class")),
  y = percentage,
  fill = factor(survived)
)) +
  geom_bar(
    stat = "identity",
    position = "dodge",
    color = "black",  # Add a black border around the bars
  ) +
  geom_text(
    aes(label = paste0(round(percentage, 1), "%")),
    position = position_dodge(width = 0.8),
    vjust = -0.5,
    size = 3
  ) +
  labs(
    title = "Survival Rate by Passenger Ticket Class",
    x = "Passenger Ticket Class",
    y = "Survival Percentage",
    fill = "Survived"
  ) +
  scale_fill_manual(
    values = SurvivedColors,
    name = "Survived",
    labels = c("Perished", "Survived")
  ) +
  theme_bw()



#----------------------End the survival rate by class of ticket-----------------

#----------------------Survival rates by fare and age---------------------------
#10. What was the survival rates by fare and age?
# Custom colors
SurvivedColours <- c("Perished" = "#D62828", "Survived" = "#003049")  # Adjust as needed

# Create a scatter plot with custom colors
ggplot(
  TitanicData,
  aes(
    x = age,
    y = fare,
    color = factor(survived, labels = c("Perished", "Survived")),
    size = fare
  )
) +
  geom_point(alpha = 0.7) +
  scale_color_manual(values = SurvivedColours) +  # Set custom colors
  labs(
    title = "Scatter Plot of Fare vs Age by Survival Status",
    x = "Passenger Age",
    y = "Ticket Fare",
    color = "Survival Status",
    size = "Ticket Fare"
  ) +
  theme_minimal()


#----------------------End survival rates by fare and age-----------------------

#--------------Multi-variate analysis pclass – sex – survived-------------------
#11. Multi-variate analysis pclass – sex – survived
# Create a summary using tidyverse
ResultSummary <- TitanicData %>%
  group_by(pclass, sex, survived) %>%
  summarise(Count = n()) %>%
  pivot_wider(names_from = survived, values_from = Count, names_prefix = "Survived_")

# Display the result
print(ResultSummary)

#12.-------Passenger Survival by Class and Gender------------------- 

# Summarize the data to count the number of passengers by Pclass, Sex, and Survived
summary_data <- TitanicData %>%
  group_by(pclass, sex, survived) %>%
  summarise(Count = n(), .groups = 'drop') # Use .groups = 'drop' to prevent grouping in the summarized data

# Plot the data with black borders around the bars
ggplot(summary_data, aes(x = pclass, y = Count, fill = as.factor(survived))) +
  geom_bar(stat = 'identity', position = 'dodge', color = 'black') +
  facet_grid(. ~ sex) + # Separate plots for male and female
  scale_x_continuous(breaks = 1:3, labels = c("1st Class", "2nd Class", "3rd Class")) +
  scale_fill_manual(values = c('#D62828', '#F77F00'), labels = c('Perished', 'Survived')) +
  labs(title = 'Passenger Survival by Class and Gender',
       x = 'Passenger Class',
       y = 'Count of Passengers',
       fill = 'Survival Status') +
  theme_minimal()

#------------------------End Multi-variate analysis-----------------------------

# Export data frame to a CSV file
write.csv(TitanicData, "Trained-Titanic.csv", row.names = FALSE)